let t2g;
let canvasW;
let canvasH;
let nrInputs;
let myCanvas;
let nrTxtMove = 1;
let c2 = '#ffffff';
let c3 = '#ffffff';
let backColorValue;
let t = 0;
let angle = 0;

function setup() {
  canvasW = windowHeight - windowHeight / 2.877;
  canvasH = windowHeight - 60;
  myCanvas = createCanvas(canvasW, canvasH);

  myCanvas.mouseMoved(moveC);
  myCanvas.mousePressed(clickC);

  newX1 = 20;
  newY1 = 20;

  newX2 = 20;
  newY2 = 590;

  newX3 = 20;
  newY3 = 640;

  ctx = myCanvas.drawingContext;

  t2g = createGraphics(canvasW, canvasH);


  movethisT1 = select("#movethis1").mouseClicked(mov1);
  movethisT2 = select("#movethis2").mouseClicked(mov2);
  movethisT3 = select("#movethis3").mouseClicked(mov3);

  nrInputs = select("#inputN");

  backColor = select("#inputColorBack");

  textInput1 = select("#textHTML1");
  textSizeInput1 = select("#inputTextSize1");
  textLeadInput1 = select("#inputTextLead1");
  textColorInput1 = select("#inputTextColor1");
  textStrokeColorInput1 = select("#strokeColor1");
  textOpacInput1 = select("#opacText1");
  strokeW1 = select("#strokeW");
  rotate1 = select("#rText1");
  fontSelection1 = select("#fontSelect1");

  emberlyWeight = select("#vWeight1");
  emberlyWidth = select("#vWidth1");

  inconsolataWeight = select("#vWeight2");
  inconsolataWidth = select("#vWidth2");

  kyivWeight = select("#vWeight3");
  kyivContrast = select("#vContrast");
  kyivMidline = select("#vMidline");

  minipaxWeight = select("#vWeight4");

  recursiveWeight = select("#vWeight5");
  recursiveCasual = select("#vCasual");
  recursiveMono = select("#vMono");
  recursiveSlant = select("#vSlant");
  recursiveItalic = select("#vItalic");

  scienceWeight = select("#vWeight6");
  scienceWidth = select("#vWidth3");
  scienceYopaque = select("#vYopaque");
  scienceSlant = select("#vSlant2");

  tracking = select("#inputTextTrack1");
  wordspace = select("#inputTextWSpace1");

  textInput2 = select("#textHTML2");
  textSizeInput2 = select("#inputTextSize2");
  textLeadInput2 = select("#inputTextLead2");
  textColorInput2 = select("#inputTextColor2");
  textOpacInput2 = select("#opacText2");
  rotate2 = select("#rText2");

  textInput3 = select("#textHTML3");
  textSizeInput3 = select("#inputTextSize3");
  textLeadInput3 = select("#inputTextLead3");
  textColorInput3 = select("#inputTextColor3");
  textOpacInput3 = select("#opacText3");
  rotate3 = select("#rText3");

  radioInput1 = select("#normalR").elt;
  compLines = select("#vNumber");
  compOffsetY = select("#vOffsetY");
  compOffsetX = select("#vOffsetX");

  radioInput2 = select("#gridR").elt;
  compLinesGC = select("#gCNumber");
  compLinesGR = select("#gRNumber");
  compOffsetYG = select("#gYOffset");
  compOffsetXG = select("#gXOffset");

  checkboxInput1 = select("#checkBoxWeightWave").elt;
  checkboxInput2 = select("#checkBoxSizeWave").elt;
  checkboxInput3 = select("#checkBoxTrackingWave").elt;
  checkboxInput4 = select("#checkBoxWSpaceWave").elt;
  checkboxInput5 = select("#checkBoxLeadingWave").elt;

  checkboxInput1_1 = select("#checkBoxIWeightWave").elt;
  checkboxInput2_1 = select("#checkBoxISizeWave").elt;
  checkboxInput3_1 = select("#checkBoxITrackingWave").elt;
  checkboxInput4_1 = select("#checkBoxIWSpaceWave").elt;
  checkboxInput5_1 = select("#checkBoxILeadingWave").elt;

  radioInput3 = select("#sideToSideR").elt;
  radioInput4 = select("#aroundR").elt;

  xposLong = select("#xLong");
  xposVelo = select("#xVelo");
  xposOff = select("#xOffset");

  yposLong = select("#yLong");
  yposVelo = select("#yVelo");
  yposOff = select("#yOffset");

  opacVelocity = select("#opacVelo");
  opacVOff = select("#opacOffset");

  savePNGButton = select('#savePNGFile'); //Variável que guarda o "valor" do botão JPG
  savePNGButton.mouseClicked(savePNGImage); //Se clicar no botão chama função e guarda imagem JPG

  savePNGButtonS = select('#savePNGFileS'); //Variável que guarda o "valor" do botão JPG


  frameRate();
}


function draw() {

  backColorValue = backColor.value();
  background(backColorValue);



  numbInputs = nrInputs.value();
  //print(numbInputs);

  drawtext2();

  ctx.font = 'sans';

  letterS = tracking.value();
  wordS = wordspace.value();


  if (checkboxInput3.checked) {
    letterS = map(sin(angle), -1, 1, 0, 30);
  }
  if (checkboxInput3_1.checked) {
    letterS = map(sin(angle), 1, -1, 0, 30);
  }

  if (checkboxInput4.checked) {
    wordS = map(sin(angle), -1, 1, 0, 30);
  }
  if (checkboxInput4_1.checked) {
    wordS = map(sin(angle), 1, -1, 0, 30);
  }

  select('canvas').elt.style.letterSpacing = letterS.toString() + "px";
  select('canvas').elt.style.wordSpacing = wordS.toString() + "px";

  //VARIABLE FONTS SETTINGS  
  weight1 = int(emberlyWeight.value());
  width1 = int(emberlyWidth.value());

  weight2 = int(inconsolataWeight.value());
  width2 = int(inconsolataWidth.value());

  weight3 = int(kyivWeight.value());
  contrast1 = int(kyivContrast.value());
  midline1 = map(int(kyivMidline.value()), 0, 1000, -1000, 0);

  weight4 = int(minipaxWeight.value());

  weight5 = int(recursiveWeight.value());
  casual = map(int(recursiveCasual.value()), 0, 100, 0, 1);
  mono = map(int(recursiveMono.value()), 0, 100, 0, 1);
  slant = map(int(recursiveSlant.value()), 0, 150, -15, 0);
  italic = int(recursiveItalic.value());

  weight6 = int(scienceWeight.value());
  width3 = int(scienceWidth.value());
  yopaque = int(scienceYopaque.value());
  slant2 = map(int(scienceSlant.value()), 0, 100, -10, 0);

  angle += 0.05;
  if (checkboxInput1.checked) {
    weight1 = map(sin(angle), -1, 1, 100, 900);
    weight2 = map(sin(angle), -1, 1, 275, 900);
    weight3 = map(sin(angle), -1, 1, 0, 1000);
    weight4 = map(sin(angle), -1, 1, 100, 600);
    weight5 = map(sin(angle), -1, 1, 300, 900);
    weight6 = map(sin(angle), -1, 1, 100, 900);
  }
  if (checkboxInput1_1.checked) {
    weight1 = map(sin(angle), 1, -1, 100, 900);
    weight2 = map(sin(angle), 1, -1, 275, 900);
    weight3 = map(sin(angle), 1, -1, 0, 1000);
    weight4 = map(sin(angle), 1, -1, 100, 600);
    weight5 = map(sin(angle), 1, -1, 300, 900);
    weight6 = map(sin(angle), 1, -1, 100, 900);
  }

  let size1 = int(textSizeInput1.value());
  let nSize1 = int(textSizeInput1.value());
  if (checkboxInput2.checked) {
    nSize1 = map(sin(angle), -1, 1, size1, size1 + 40);
  }
  if (checkboxInput2_1.checked) {
    nSize1 = map(sin(angle), 1, -1, size1, size1 + 40);
  }

  let lead1 = int(textLeadInput1.value());
  let nLead1 = int(textLeadInput1.value());
  if (checkboxInput5.checked) {
    nLead1 = map(sin(angle), -1, 1, lead1, lead1 + 60);
  }
  if (checkboxInput5_1.checked) {
    nLead1 = map(sin(angle), 1, -1, lead1, lead1 + 60);
  }


  if (fontSelection1.value() == 1) {
    select('canvas').elt.style.fontVariationSettings = "'wght' " + weight1.toString() + ", 'wdth' " + width1.toString();
  } else if (fontSelection1.value() == 2) {
    select('canvas').elt.style.fontVariationSettings = "'wght' " + weight1.toString() + ", 'wdth' " + width1.toString();
  } else if (fontSelection1.value() == 3) {
    select('canvas').elt.style.fontVariationSettings = "'wght' " + weight2.toString() + ", 'wdth' " + width2.toString();
  } else if (fontSelection1.value() == 4) {
    select('canvas').elt.style.fontVariationSettings = "'wght' " + weight3.toString() + ", 'CONT' " + contrast1.toString() + ", 'MIDL' " + midline1.toString();
  } else if (fontSelection1.value() == 5) {
    select('canvas').elt.style.fontVariationSettings = "'wght' " + weight3.toString() + ", 'CONT' " + contrast1.toString() + ", 'MIDL' " + midline1.toString();
  } else if (fontSelection1.value() == 6) {
    select('canvas').elt.style.fontVariationSettings = "'wght' " + weight3.toString() + ", 'CONT' " + contrast1.toString() + ", 'MIDL' " + midline1.toString();
  } else if (fontSelection1.value() == 7) {
    select('canvas').elt.style.fontVariationSettings = "'wght' " + weight4.toString();
  } else if (fontSelection1.value() == 8) {
    select('canvas').elt.style.fontVariationSettings = "'MONO' " + mono.toString() + ", 'CASL' " + casual.toString() + ", 'wght' " + weight5.toString() + ", 'slnt' " + slant.toString() + ", 'CRSV' " + italic.toString();
  } else if (fontSelection1.value() == 9) {
    select('canvas').elt.style.fontVariationSettings = "'wght' " + weight6.toString() + ", 'wdth' " + width3.toString() + ", 'YOPQ' " + yopaque.toString() + ", 'slnt'" + slant2.toString();
  }

  c1 = color(textColorInput1.value());
  c1.setAlpha(textOpacInput1.value());

  c2 = color(textColorInput2.value());
  c2.setAlpha(textOpacInput2.value());

  c3 = color(textColorInput3.value());
  c3.setAlpha(textOpacInput3.value());

  if (radioInput1.checked) {
    numberCompLines = compLines.value();
    cOffsetY = compOffsetY.value();
    cOffsetX = compOffsetX.value();
  } else {
    numberCompLines = 0;
  }

  if (radioInput2.checked) {
    numberCompLinesGC = compLinesGC.value();
    numberCompLinesGR = compLinesGR.value();
    cOffsetYG = compOffsetYG.value();
    cOffsetXG = compOffsetXG.value();
  } else {
    numberCompLinesG = 0;
  }

  oV = opacVelocity.value();
  oO = opacVOff.value();

  xposL = xposLong.value();
  xposV = xposVelo.value();
  xposO = xposOff.value();

  yposL = yposLong.value();
  yposV = yposVelo.value();
  yposO = yposOff.value();


  t++;
  //TITLE
  push();
  translate(newX1, newY1);

  fill(c1);
  strokeWeight(map(strokeW1.value(), 0, 10, 0, 4));
  strokeCap(SQUARE);
  stroke(textStrokeColorInput1.value());

  if (fontSelection1.value() == 1) {
    textFont('Emberly');
  } else if (fontSelection1.value() == 2) {
    textFont('Emberly Italic');
  } else if (fontSelection1.value() == 3) {
    textFont('Inconsolata');
  } else if (fontSelection1.value() == 4) {
    textFont('Kyiv Sans');
  } else if (fontSelection1.value() == 5) {
    textFont('Kyiv Serif');
  } else if (fontSelection1.value() == 6) {
    textFont('Kyiv Titling');
  } else if (fontSelection1.value() == 7) {
    textFont('Minipax');
  } else if (fontSelection1.value() == 8) {
    textFont('Recursive');
  } else if (fontSelection1.value() == 9) {
    textFont('Science Gothic');
  }

  textSize(nSize1);
  textStyle(NORMAL);

  if (alignment == 1) {
    textAlign(LEFT, TOP);
  } else if (alignment == 2) {
    textAlign(CENTER, TOP);
  } else if (alignment == 3) {
    textAlign(RIGHT, TOP);
  }

  textLeading(nLead1);

  rotate(map(rotate1.value(), 0, 360, 0, 6.285));



  if (radioInput1.checked) {
    for (var a = 0; a <= numberCompLines; a++) {
      var opac;
      if (oV == 0) {
       fill(c1);
      } else if (oV => 1) {
        opac = 255 * sin(radians(t * oV + a * oO));
      c1t = color(textColorInput1.value());
      c1t.setAlpha(map(opac, -255, 255, 20, 255));
      fill(c1t);
      }


      if (radioInput3.checked) {
        animType = sin;
      }
      if (radioInput4.checked) {
        animType = tan;

      }
      var dxOff = xposL * animType(radians(t * xposV + a * xposO));
      var dyOff = yposL * sin(radians(t * yposV + a * yposO));

      text(textInput1.value(), dxOff + cOffsetX * a, dyOff + cOffsetY * a);
    }
  } else if (radioInput2.checked) {
    for (var b = 0; b <= numberCompLinesGR; b++) {
      for (var c = 0; c <= numberCompLinesGC; c++) {
        var opac2;
        if (oV == 0) {
          fill(c1);
        } else if (oV => 1) {
          opac2 = 255 * sin(radians(t * oV + c * oO) + b);
          
        c1t = color(textColorInput1.value());
        c1t.setAlpha(map(opac2, -255, 255, 20, 255));

        fill(c1t);
        }



        if (radioInput3.checked) {
          animType = sin;
        }
        if (radioInput4.checked) {
          animType = tan;

        }
        var dxOff2 = xposL * animType(radians(t * xposV + b * xposO) + c);
        var dyOff2 = yposL * sin(radians(t * yposV + b * yposO) + c);

        text(textInput1.value(), dxOff2 + cOffsetXG * c, dyOff2 + cOffsetYG * b);
      }
    }
  } else if (!radioInput1.checked || !radioInput2.checked) {
    var opac0;
      if (oV == 0) {
        opac0 = 255;
      } else if (oV => 1) {
        opac0 = 255 * sin(radians(t * oV));
      }


      c1t = color(textColorInput1.value());
      c1t.setAlpha(map(opac0, -255, 255, 20, 255));

    if (oV == 0) {
        fill(c1);
      } else if (oV => 1) {
        fill(c1t);
      }
      

      if (radioInput3.checked) {
        animType = sin;
      }
      if (radioInput4.checked) {
        animType = tan;

      }
      var dxOff0 = xposL * animType(radians(t * xposV));
      var dyOff0 = yposL * sin(radians(t * yposV));

      text(textInput1.value(), dxOff0 + 0, dyOff0 + 0);
    
  }

  pop();
  //END OF TEXT 01


  savePNGButtonS.mouseClicked(savePNGImageS); //Se clicar no botão chama função e guarda imagem JPG
}

function drawtext2() {

  if (numbInputs == 2) {

    t2g.background(backColorValue);
    t2g.fill(c2);
    t2g.textSize(int(textSizeInput2.value()));
    if (alignment2 == 1) {
      t2g.textAlign(LEFT, TOP);
    } else if (alignment2 == 2) {
      t2g.textAlign(CENTER, TOP);
    } else if (alignment2 == 3) {
      t2g.textAlign(RIGHT, TOP);
    }
    t2g.textLeading(int(textLeadInput2.value()));
    t2g.textFont('Helvetica');
    if (style == 1) {
      t2g.textStyle(NORMAL);
    } else if (style == 2) {
      t2g.textStyle(BOLD);
    } else if (style == 3) {
      t2g.textStyle(ITALIC);
    } else if (style == 4) {
      t2g.textStyle(BOLDITALIC);
    }
    t2g.push();
    t2g.translate(newX2, newY2);
    t2g.rotate(map(rotate2.value(), 0, 360, 0, 6.285));

    t2g.text(textInput2.value(), 0, 0);
    t2g.pop();
    image(t2g, 0, 0);


  } else if (numbInputs == 3) {
    t2g.background(backColorValue);
    t2g.fill(c2);
    t2g.textSize(int(textSizeInput2.value()));
    if (alignment2 == 1) {
      t2g.textAlign(LEFT, TOP);
    } else if (alignment2 == 2) {
      t2g.textAlign(CENTER, TOP);
    } else if (alignment2 == 3) {
      t2g.textAlign(RIGHT, TOP);
    }
    t2g.textLeading(int(textLeadInput2.value()));
    t2g.textFont('Helvetica');
    if (style == 1) {
      t2g.textStyle(NORMAL);
    } else if (style == 2) {
      t2g.textStyle(BOLD);
    } else if (style == 3) {
      t2g.textStyle(ITALIC);
    } else if (style == 4) {
      t2g.textStyle(BOLDITALIC);
    }
    t2g.push();
    t2g.translate(newX2, newY2);
    t2g.rotate(map(rotate2.value(), 0, 360, 0, 6.285));
    t2g.text(textInput2.value(), 0, 0);
    t2g.pop();


    t2g.fill(c3);
    t2g.textSize(int(textSizeInput3.value()));
    if (alignment3 == 1) {
      t2g.textAlign(LEFT, TOP);
    } else if (alignment3 == 2) {
      t2g.textAlign(CENTER, TOP);
    } else if (alignment3 == 3) {
      t2g.textAlign(RIGHT, TOP);
    }
    t2g.textLeading(int(textLeadInput3.value()));
    t2g.textFont('Helvetica');
    if (style2 == 1) {
      t2g.textStyle(NORMAL);
    } else if (style2 == 2) {
      t2g.textStyle(BOLD);
    } else if (style2 == 3) {
      t2g.textStyle(ITALIC);
    } else if (style2 == 4) {
      t2g.textStyle(BOLDITALIC);
    }
    t2g.push();
    t2g.translate(newX3, newY3);
    t2g.rotate(map(rotate3.value(), 0, 360, 0, 6.285));
    t2g.text(textInput3.value(), 0, 0);
    t2g.pop();
    image(t2g, 0, 0);
  }
}


function savePNGImageS() {

  saveFrames('variantype_seq', 'png', 1, 30);


  //for (let m = 0; m <= 30; m++) {
  //saveCanvas('variantype_' + m + '.png');
  //}

  //noLoop();

}

function savePNGImage() {
  saveCanvas('variantype.png');
}

function moveC() {
  if (mouseIsPressed) {
    cursor('grabbing');

    if (nrTxtMove == 1) {
      newX1 = mouseX - xOffset1;
      newY1 = mouseY - yOffset1;
    } else if (nrTxtMove == 2) {
      newX2 = mouseX - xOffset2;
      newY2 = mouseY - yOffset2;
    } else if (nrTxtMove == 3) {
      newX3 = mouseX - xOffset3;
      newY3 = mouseY - yOffset3;
    }
  } else {
    cursor('grab');
  }
}


function clickC() {

  xOffset1 = mouseX - newX1;
  yOffset1 = mouseY - newY1;

  xOffset2 = mouseX - newX2;
  yOffset2 = mouseY - newY2;
  xOffset3 = mouseX - newX3;
  yOffset3 = mouseY - newY3;

  //print(xOffset);
}


function mov1() {
  nrTxtMove = 1;
  //print(nrTxtMove);
}

function mov2() {
  nrTxtMove = 2;
  //print(nrTxtMove);
}

function mov3() {
  nrTxtMove = 3;
  //print(nrTxtMove);
}